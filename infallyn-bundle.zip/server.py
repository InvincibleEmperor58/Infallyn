"""Tiny static server for the Infallyn app — serves the app at /, /app and /infallyn."""
import http.server, socketserver, functools

PORT = 8000
APP = "infallyn.html"

class Handler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path in ("/", "/app", "/infallyn", "/index.html"):
            self.path = "/" + APP
        return super().do_GET()
    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

with socketserver.TCPServer(("0.0.0.0", PORT), functools.partial(Handler, directory="/home/user")) as httpd:
    print(f"Infallyn serving on 0.0.0.0:{PORT}")
    httpd.serve_forever()

# Infallyn — personal study platform (single-file web app)

A private, offline-first productivity & study app in **one HTML file**: task/document shelf,
nightly spaced-repetition "Daily Dose", handwriting OCR → text-to-speech, home-screen-style
widgets, and per-user **passphrase-encrypted accounts** — crowned-kingfisher emblem baked in
as the app icon and in-app mark. No frameworks, no build step required to run, no server, no tracking.

---

## 1. Quick start (pick any)

| Option | How | Notes |
|---|---|---|
| **Just open it** | Double-click `app/infallyn.html` | Full app; OCR loads from CDN when online |
| **Serve it** | `python3 server.py` → http://localhost:8000 | Recommended: real origin = stable localStorage + IndexedDB (serves `/`, `/app`, `/infallyn`) |
| **Any static host** | Upload `app/infallyn.html` as `index.html` | GitHub Pages, Netlify, S3, etc. all work |

- Everything works offline except OCR recognition (Tesseract.js is fetched from a CDN at
  runtime; when offline the app gracefully falls back to manual text entry).
- Voice output uses your browser/system voices (free, private, on-device).
- Run built-in self-tests: open the app with `?selftest=1` in the URL.

## 2. Accounts & where data lives

- First screen = lock screen. **Create an account** (name + passphrase ≥ 6 chars + optional hint).
- Passphrase → PBKDF2 (150k iters, SHA-256) → AES-256-GCM key. The whole state JSON *and every
  photo* are encrypted with it. Only a verifier is stored — never the passphrase. Without the
  passphrase the data cannot be decrypted (there is no reset — that is the design).
- "Stay signed in" wraps the key with a random device key for auto-unlock on that browser.
- Storage keys used:
  - `localStorage`: `infallyn.accounts.v1`, `infallyn.vault.<user>`, `infallyn.autologin.<user>`,
    `infallyn.lastuser`, `infallyn.devicekey`, (legacy pre-account: `infallyn.state.v1`)
  - `IndexedDB` `infallyn-media`: per-user namespace `u/<user>/<mediaId>`, each value an
    `{"iv":…,"ct":…}` AES-GCM envelope.
- Multiple accounts per device are fully isolated (separate vault + media namespace).
- Note: versions before the "Infallyn" rebrand used differently-named storage keys and DB;
  those old keys are **not** read by this build (it was pre-release — nothing to migrate).

## 3. File map

```
infallyn-bundle/
├── README.md                        ← you are here
├── server.py                        tiny static server (port 8000, serves the app at /, /app, /infallyn)
├── app/
│   └── infallyn.html                ★ THE WHOLE APP — single self-contained file (~163 KB)
├── src/                             ← editable source modules (assembled by build.sh)
│   ├── head.html                    doctype, meta, icons, <style> opener
│   ├── app.css                      design system (tokens, themes, components, dose session, lock screen)
│   ├── body.html                    app shell: widgets, bottom nav, capture/editor/transcript/search
│   │                                 sheets, welcome, dose overlay, lock screen markup
│   ├── core.js                      utils · safe localStorage · encrypted per-user media store ·
│   │                                 state · smart date parser · FSRS-style scheduler · queue ·
│   │                                 streaks (grace night) · sentence splitter · seed content · self-tests
│   ├── auth.js                      Auth (PBKDF2/AES-GCM vaults, stay-signed-in, autolock, boot)
│   │                                 + LK lock-screen UI + legacy-content claim flow
│   ├── ui1.js                       toasts · player/TTS engine · OCR engine (Tesseract CDN w/
│   │                                 offline fallback) · capture & scan flows · editors · memory
│   │                                 cards · nightly dose session (flip/swipe/grade) + auto-lock hook
│   ├── ui2.js                       router · renderers (shelf/dose/listen/you) · reminders &
│   │                                 dose notifications · search · export/import · theme · app lifecycle
│   ├── tail.html                    </script></body></html>
│   └── build.sh                     assembles the single file (order: head→css→body→core→auth→ui1→ui2→tail)
└── docs/
    └── infallyn-specification.md    full product & technical spec (architecture, workflows, UX)
```

## 4. Rebuilding after edits

```bash
cd src && ./build.sh        # → regenerates ../infallyn.html (runs node --check as a gate)
```

Node is optional (only for the syntax check); the build is plain `cat` concatenation.

## 5. Feature checklist

- **Shelf (Pillar 1):** tasks/notes/documents · smart capture with natural-language parsing
  ("read ch4 tomorrow 9pm !! #tag /shelf *") · Today/Inbox/Upcoming/Anytime · shelves, tags,
  pins, priorities · reminders (in-app + Web Notifications) · full-text search · undo toasts
- **Daily Dose (Pillar 2):** photo + note cards · FSRS-style scheduling (Again/Hard/Good/Easy with
  interval previews) · swipe or keyboard (space=flip, 1–4=grade) · nightly trigger + one re-nudge ·
  streaks with 1 grace night/week · 13-week heatmap · 7-day forecast · card management (suspend/delete)
- **OCR→Audio (Pillar 3):** multi-page scan flow · real handwriting/print recognition (Tesseract.js)
  · trust screen (confidence badge, suspicious-word chips, editable text) · originals kept encrypted
  · listening room: sentence transcript with karaoke highlight, tap-to-seek, 0.75×–3× speed,
  voice picker, sleep timer, queue auto-advance, mini-player + widget transport controls
- **Smart access (Pillar 4):** Dose-ring / Next-Up / Now-Playing widgets · deep links
  (`#/dose/start`, `#/item/<id>`, …) · keyboard shortcuts · light "Reading Room" / warm-dark
  "Night Shelf" themes · export/import full JSON (media included)
- **Accounts:** lock screen, account chips, stay-signed-in, auto-lock when tab hidden, lock vs
  sign-out vs switch, per-account encrypted export, legacy content claim

## 6. Primer for a new AI chat

> This is "Infallyn", a single-file offline-first web app (vanilla JS, no build step).
> The whole app is `app/infallyn.html`; `src/` holds the same code as editable modules
> concatenated by `src/build.sh` in this order: head.html + app.css + body.html + core.js +
> auth.js + ui1.js + ui2.js + tail.html. core.js is DOM-free domain logic (state in global `S`,
> FSRS-style scheduler, smart parser, encrypted media store `Media`, safe `Store` wrapper).
> auth.js holds the passphrase account system (`Auth` + lock screen `LK`): per-user AES-256-GCM
> vaults in localStorage (`infallyn.vault.<user>`), media in IndexedDB `infallyn-media` under
> `u/<user>/`. ui1.js: player (Web Speech TTS), OCR (Tesseract via CDN, graceful offline),
> capture/scan/edit flows, the nightly "Daily Dose" session overlay (`DZ`). ui2.js: hash router
> (`#/shelf`, `#/dose`, `#/listen`, `#/you`), renderers, reminders/tick loop, settings,
> export/import, lifecycle (`Auth.boot()` → `LK` → `startApp()`). The app global is
> `window.Infallyn` (short alias `L`). To run: any static server (see server.py) or just open
> the HTML. Self-tests: `?selftest=1`.
